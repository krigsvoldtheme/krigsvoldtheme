import { run } from './server.mjs';
await run('krigsvold',new URL('./catalog.json',import.meta.url));
