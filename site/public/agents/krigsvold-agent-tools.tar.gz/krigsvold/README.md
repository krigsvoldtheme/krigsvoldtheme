# krigsvold agent tools

Experimental MIT local stdio MCP and companion builder skill. Source https://github.com/k3jph/design-workbench/tree/39d664082bb0dbdb09bc182a6abffebef75518ff; content digest 4ace73f9d74fd4ba9442a42117e56bbd0d4cd23e24bda211d5149f91b127074c.

Run npm install --ignore-scripts in this directory, then configure a stdio MCP client with command node and args ["/absolute/path/to/index.mjs"]. The client starts the process. The server exposes get_manifest, search_guidance, get_reference, and exact resources. Confirm the family using get_manifest.

Copy krigsvold-builder into your client's supported skills directory. Hosted setup and actual package availability are recorded by get_manifest; no static-audit or production-accessibility certification is claimed. This archive includes no workbench server or database.
