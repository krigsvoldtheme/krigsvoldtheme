# krigsvold agent tools

Experimental MIT local stdio MCP and companion builder skill. Source https://github.com/howardjp/design-workbench/tree/3141ee8ed3433bbf6be19e78aa1df168c9479a31; content digest 06024ed3e279d205d92d156f635de4ce896799fc51bd1e9debe94b5790c8a68a.

Run npm install --ignore-scripts in this directory, then configure a stdio MCP client with command node and args ["/absolute/path/to/index.mjs"]. The client starts the process. The server exposes get_manifest, search_guidance, get_reference, and exact resources. Confirm the family using get_manifest.

Copy krigsvold-builder into your client's supported skills directory. Hosted setup and actual package availability are recorded by get_manifest; no static-audit or production-accessibility certification is claimed. This archive includes no workbench server or database.
